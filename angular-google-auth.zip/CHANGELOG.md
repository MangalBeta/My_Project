Version numbers correspond to `bower.json` version

# 1.0.4
## Features
- do NOT request feeds (contacts) scope/permission for email (this was a hack fix for google not always returning email but we're assuming Google fixed this now)


# 1.0.3
## Features
- return `rawData` of Google user profile data (i.e. includes `gender`)


# 1.0.2
## Bug Fixes
- make getContacts function public


# 1.0.1
## Bug Fixes
- fixed scopeHelp parameter support

# 1.0.0

## Features

## Bug Fixes

## Breaking Changes